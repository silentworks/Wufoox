--------------------
Wufoox
--------------------
Version: 1.0.0
Since: March 28, 2012
Author: Andrew Smith <a.smith@silentworks.co.uk>

--------------------

Wufoo Form integration TV for MODx

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/silentworks/Wufoox/issues
