<?php
$_lang['wufoox'] = 'Wufoox';
$_lang['wufoox.btn.normal'] = 'Select Wufoo Form';
$_lang['wufoox.btn.change'] = 'Change Wufoo Form';
