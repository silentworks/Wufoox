<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7404878bb1f0d5d7d817f9f8f0fd4644',
      'native_key' => 'wufoox',
      'filename' => 'modNamespace/8b760fc6121d37c9e4fdc6936ccf73ce.vehicle',
      'namespace' => 'wufoox',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'f1f44c4288e4a49511f5e92e845f0167',
      'native_key' => 1,
      'filename' => 'modPlugin/ec4e25d734612adc4d1e531eb37a460c.vehicle',
      'namespace' => 'wufoox',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '23ca6a9116c14fc4b9e3f24f952b4954',
      'native_key' => 1,
      'filename' => 'modCategory/bc85f933bff761c2b7e55699e25b177c.vehicle',
      'namespace' => 'wufoox',
    ),
  ),
);